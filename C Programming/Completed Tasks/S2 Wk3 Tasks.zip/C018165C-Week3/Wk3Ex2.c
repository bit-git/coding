/* 
 * File:   WK3Task2.c
 * Author: Omer Chohan - c018165c
 *
 * Created on 18 February 2014, 15:23
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Wk3Ex2.h"		/* conatins structure definition */

/***********************************************************		
     Function Prototypes 
     Note that variable names have been removed as they are 
     not actually required - they are optional
************************************************************/
 
int fnMenu(void);
strPerson *fnAddItem( strPerson *);
void fnPrintList( strPerson *);
void fnSearchList( strPerson *);
struct strPerson *fnRemoveStartItem( strPerson *);
struct strPerson *fnRemoveEndItem( strPerson *);


/******** 
   Main 
*********/

int main(int argc, char *argv[]) {
    
    strPerson *ptrHead = NULL;
    strPerson *ptrTemp = NULL;
    int nChoice = 0;
    int nRun = 1;
    char str[20];

    while (nRun) {
        nChoice = fnMenu();

        switch (nChoice) {
            case 1: /* Add an item */
                
                system("cls");
                
                ptrHead = fnAddItem(ptrHead);
                printf("\n\t1 Item successfully added.\n\n");
                
                system("pause");
                break;

            case 2: /* Print the list */
                 
                system("cls");
                
                fnPrintList(ptrHead);
                
                system("pause");
                break;

            case 3: /* Search the list */
            
                system("cls");
                
                fnSearchList(ptrHead);
                
                system("pause");                
                break;
                

            case 4: /* Remove a start item */
            
                system("cls");
                
                ptrHead = fnRemoveStartItem(ptrHead);
                
                system("pause");
                break;
                

            case 5: /* Remove an end item */
                
                system("cls");
                
                fnRemoveEndItem(ptrHead);
                
                system("pause");
                break;
                

            case 6: /* Exit program */
            
                nRun = 0; /* set to zero to stop the while loop */
                
                break;
        }
    }

    return 0;
}

/*************
Menu Function
**************/

int fnMenu(void) {
    int nChoice;

    system("cls");
    
    printf("\n\n\t*** Menu ***\n\n");
    printf("\t1. ADD an item.\n");
    printf("\t2. PRINT list.\n");
    printf("\t3. SEARCH for a first name value.\n");
    printf("\t4. DELETE a start item.\n");
    printf("\t5. DELETE an end item.\n");
    printf("\t6. EXIT.\n\n");
    printf("\tPlease enter a choice : ");
    scanf("\t%d", &nChoice);
    printf("\n\n");

    return nChoice;
}

/*****************
Function Add item
******************/

struct strPerson *fnAddItem(strPerson *ptrHead) {
    
    struct strPerson *ptrTemp = NULL;

    if (ptrHead == NULL) {
                
        /* Special case - list empty */
        ptrHead = (strPerson *) malloc(sizeof (strPerson));
        
        if (ptrHead == NULL) {
            printf("\tAdding to an empty list - malloc has failed.\n");
            exit(1);
        }
        
        /* malloc has worked - set values */
        fflush(stdin);
        
        printf("\n\n");
        printf("\tEnter Person details.\n");
        printf("\tPerson ID : ");
        gets(ptrHead -> arcPersonID);
        printf("\tFirst Name : ");
        gets(ptrHead -> arcFirstName);
        printf("\tMiddle Name : ");
        gets(ptrHead -> arcMiddleName);
        printf("\tLast Name : ");
        gets(ptrHead -> arcLastName);
        printf("\tSex (M/F) : ");
        gets(&ptrHead -> cSex);
        printf("\tDate of Birth (DD/MM/YYYY); \n\tDay (1-31) : ");
        scanf("%d", &ptrHead->strDOB.nDay);
        printf("\tMonth (1-12) : ");
        scanf("%d", &ptrHead -> strDOB.nMonth);
        printf("\tYear (YYYY) : ");
        scanf("\t%d", &ptrHead -> strDOB.nYear);
        
        ptrHead -> ptrNext = NULL; 				/* This is important as it signals
												the last node within the list */
    } else {
        	/*There are items already in the list
            need to locate the end - use a while loop
            to step through looking for ptrNext to
            equal NULL */

        ptrTemp = ptrHead;          /* Use a temp pointer */
        						
        while (ptrTemp -> ptrNext != NULL) {
            									/* As ptrNext has a value there is a node
                   	 							hanging off it */
            ptrTemp = ptrTemp -> ptrNext;
        }
                /* ptrTemp is now pointing at the last node1
                within the list
                Now, create a new node that "hangs off"
                ptrNext within this last node  */

        ptrTemp -> ptrNext = (struct strPerson *) malloc(sizeof (strPerson));
        
        if (ptrTemp -> ptrNext == NULL) {
            printf("\tAdding to end of list - malloc has failed\n");
            exit(1);
        }
                
        fflush(stdin);
        
        printf("\n\n");
        printf("\tEnter Person details.\n");
        printf("\tPerson ID : ");
        gets(ptrTemp -> ptrNext -> arcPersonID);
        printf("\tFirst Name : ");
        gets(ptrTemp -> ptrNext -> arcFirstName);
        printf("\tMiddle Name : ");
        gets(ptrTemp -> ptrNext -> arcMiddleName);
        printf("\tLast Name : ");
        gets(ptrTemp -> ptrNext -> arcLastName);
        printf("\tSex (M/F) : ");
        gets(&ptrTemp -> ptrNext -> cSex);
        printf("\tDate of Birth (DD/MM/YYYY); \n\tDay (1-31) : ");
        scanf("\t%d", &ptrTemp -> ptrNext -> strDOB.nDay);
        printf("\tMonth (1-12) : ");
        scanf("\t%d", &ptrTemp -> ptrNext -> strDOB.nMonth);
        printf("\tYear (YYYY) : ");
        scanf("\t%d", &ptrTemp -> ptrNext -> strDOB.nYear);
        ptrTemp -> ptrNext -> ptrNext = NULL;
        
    }

    return ptrHead; 		/* This is really only needed when adding the first item
							to the list - but have to do it in all cases to avoid
							error messages */
}

/*******************
Function Print List
********************/

void fnPrintList(strPerson *ptrTemp) {
    struct strPerson *ptrHead = ptrTemp;
    if (!ptrHead) {
        printf("\n\n\tList Empty.\n\n");
    } else {
        while (ptrHead) {
              
            printf("\n\n\tPerson ID : %s \n\tFirst Name : %s \n\tMiddle Name : %s \n\tLast Name : %s \n", ptrHead -> arcPersonID,
                      ptrHead -> arcFirstName, ptrHead -> arcMiddleName, ptrHead -> arcLastName);
                      
            printf("\tSex : %c \n\tD.O.B : %d/%d/%d ", 
                          ptrHead -> cSex, 
                          ptrHead -> strDOB.nDay, ptrHead -> strDOB.nMonth, ptrHead -> strDOB.nYear);
            
            ptrHead = ptrHead -> ptrNext;
            
        }
        printf("\n\n\tEnd of the list.\n\n");
    }

}

/********************
Function Search List
*********************/

void fnSearchList(strPerson *ptrHead) {
    strPerson *ptrTemp = ptrHead;
    int nCount = 0;
    char str[50];
    
    printf("\n\n\tEnter the first name to search : ");
    
    fflush(stdin);
    gets(str);

    if (!ptrHead) {
        /* Empty List */
        
        printf("\n\n\tEmpty List.\n\n");
        
    } else {
        while (ptrTemp) {

            if (strcmp(ptrTemp -> arcFirstName, str) == 0) {
                printf("\n\n\tThe value %s has been located.\n", ptrTemp -> arcFirstName);
                nCount++;
            }
            ptrTemp = ptrTemp -> ptrNext;
        }

        if (!nCount)
            printf("\n\n\tValue not found within the list.\n\n");
        else
            printf("\n\n\tA total of %d names were found.\n\n", nCount);
    }
}

/************************* 
Function Remove Start Item
**************************/

struct strPerson *fnRemoveStartItem( strPerson *ptrHead) {
    strPerson *ptrTemp = NULL;

    if (!ptrHead) {
    	
        /* Empty list */
        
		printf("\n\n\tNothing to remove list is empty.\n\n");
        return ptrHead;
    } else {
        ptrTemp = ptrHead -> ptrNext;
        free(ptrHead);
        printf("\n\n\tStart item deleted.\n\n");
        return ptrTemp;
    }
}

/***********************
Function Remove End Item
************************/

struct strPerson *fnRemoveEndItem(strPerson *ptrHead) {
	
    		/*	There are two special cases ...
            1. When the list is empty
            2. When there is only one node within the list
     		*/
     		
    struct strPerson *ptrTemp = NULL;

    if (!ptrHead) {
        /* The list is empty */
        
        printf("\n\n\tEMPTY list.\n\n");
        
    } else if (ptrHead -> ptrNext == NULL) {
    	
        		/*	There is only one node in the list
                as ptrNext within the first node
                is NULL */

        printf("\n\n\tOnly 1 item to delete.\n\n");
        
        free(ptrHead);		    /*This releases the memory allocated by malloc() back to the heap */
        								

        ptrHead = NULL; 		/*	As this was the last item to remove
								/*	need to return NULL so that ptrHead
								is set to NULL  */
    } else {
                /*	There are more than one nodes in the list,
                need to step through to find the last but
                one node */

        ptrTemp = ptrHead;
        while (ptrTemp -> ptrNext -> ptrNext) {
               ptrTemp = ptrTemp -> ptrNext;
        }

        		/*	ptrTemp is now pointing to the last but
                one node so can delete the last one */


        free(ptrTemp -> ptrNext);
        ptrTemp -> ptrNext = NULL; 		/* Set to NULL as this is 
									   now the last node */
		printf("\n\n\tLast item deleted.\n\n");							   
    }

    return ptrHead;
}
