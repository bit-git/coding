
/*	WK3Ex2.h
*
*	Structure definitions
*
*/

#define MAX_LENGTH 50
#define ID 10

/* Define the structures */

typedef struct strDate strDate;
 struct strDate
{
	int	nDay;
	int	nMonth;
	int	nYear;
};

typedef struct strPerson strPerson;
 struct strPerson
{
    char    arcPersonID[ID];         
	char	arcFirstName[MAX_LENGTH];
	char	arcMiddleName[MAX_LENGTH];
	char	arcLastName[MAX_LENGTH];
	char	cSex;
	        strDate strDOB;
            strPerson *ptrNext;
};

              /* Dont forget the semicolon */

		  		  

