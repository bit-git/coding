#include <stdio.h>

int main(void)
{
	float fValue = 12.34;

	printf("\nTut Week 1\nExample 1\n\nEfect of casting\n\n");

	printf("The value of fValue when cast as an integer is %d\n",(int)fValue);

printf("The value of fValue, after being cast, is no %f\n", fValue);

return 0;
}

