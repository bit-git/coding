
#include <stdio.h>
#include <stdlib.h>

void fnIntro(void); /* Introduction Header function */
void fnSearchArray(int arnSalaries[][2]); /* Array search function header */
void fnSortArray(int arnSalaries[][2]); /* Array sort function header */
void fnPrintArray(int arnSalaries[][2]); /* Array print function header */

int main(int argc, char *argv[])
	{
	int arnSalaries[10][2] = {21, 10000, 22, 15600, 23, 10000, 24, 56000, 25, 13250, 
	         				   26, 24750, 27, 18750, 28, 56250, 29, 22450, 30, 27500};
	
	fnIntro(); /* Introduction Header */
	
	/* First, print the unsorted array so that the contents can be seen */
	printf("\tUnsorted salaries.\n");	 
	fnPrintArray(arnSalaries); 
	
	fnSortArray(arnSalaries); /* Sort Function called in main */
	
	/* Print the sorted array so that the contents can be seen */
	printf("\tSorted salaries in ascending order.\n");	
	fnPrintArray(arnSalaries); 
	
	fnSearchArray(arnSalaries); /* Search Function */
	
	printf("\n\n");
	
	system("PAUSE");	
	return 0;
	}
	
/* Function Definitions */
	
/* Just a little intro header */
void fnIntro(void)
{
	printf("\tWeek 1 Tutorial\n\tFormative Task 2\n\tSorting a 2D array\n\tof Employee IDs and Salaries.\n\n");
}

/* Search Array */
void fnSearchArray(int arnSalaries[][2])
{
	 int nRow, nEmID; 
	 char cFound = 'N';
	 printf("\tPlease enter the employee ID : ");
	 scanf("%d", &nEmID);
	 /* Now the search */
	 for(nRow = 0; nRow < 10; nRow++)
	{
	 if(nEmID == arnSalaries[nRow][0])
		{
		printf("\n\tEmployee found - has salary of %d\n", arnSalaries[nRow][1]);
		 		
		cFound = 'Y';
		nRow = 10; /* This is to break out of the loop */
		}
	}
	
	if(cFound == 'N')
	{
	printf("\tSorry, employee not found - please try again\n");
	}
	}

/* Sort Array */
void fnSortArray(int arnSalaries[][2])
{
	int i, j, tempSalary, tempEmpID;
	
		/* Sort Algorithm */
	for(i = 0; i < 10 ; i++)
	{
		for (j=(i + 1); j < 10 ; j++)
		{
			if (arnSalaries[i][1] > arnSalaries[j][1])
			{
				tempSalary = arnSalaries[i][1];
				arnSalaries[i][1] = arnSalaries[j][1];
				arnSalaries[j][1] = tempSalary;
				
				tempEmpID = arnSalaries[i][0];
				arnSalaries[i][0] = arnSalaries[j][0];
				arnSalaries[j][0] = tempEmpID;
				
				
			}
		}
	}
	
	
}

/* Print Array */
void fnPrintArray(int arnSalaries[][2])
{
	int nRow;
	
	printf("\t%s\t%s\n \t%s\t%s\n","Emp ID","Salaries",
	 								"------","--------");
	for(nRow = 0; nRow < 10; nRow++)
	{
		 printf("\t%4d\t%6d\n",arnSalaries[nRow][0], arnSalaries[nRow][1]);
	 }
	 printf("\n\n");
}
