/*
*  File.Wk1Task4.c
*  HCS
*
*  Created by Omer Chohan on 01/02/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>



/*
*	Function prototypes to print strings
*	stored in the arrays
*/

void fnPrintString1(char arcString1[5]);
void fnPrintString2(char arcString2[10]);
void fnPrintString3(char arcString3[15]);
void fnPrintString4(char arcString4[20]);


int main(void)
{
	char arcString1[5];
	char arcString2[10];
	char arcString3[15];
	char arcString4[20];
	char arcCompositeString[100];
	
		printf("\n\n\tWeek 1 Tutorial\n\tSummative Task 4\n\tInput 4 strings\n\tof length 5, 10, 15, 20.\n\n");
		
		printf("Enter string 1 (max: 5 char including spaces): \n");
		gets(arcString1);
		
		printf("Enter string 2 (max: 10 char including spaces): \n");
		gets(arcString2);
		
		printf("Enter string 3 (max: 15 char including spaces): \n");
		gets(arcString3);
		
		printf("Enter string 4 (max: 20 char including spaces): \n");
		gets(arcString4);
	
	system("cls");	/*	Clear screen before printing output	*/
	
		fnPrintString1(arcString1);
		fnPrintString2(arcString2);
		fnPrintString3(arcString3);
		fnPrintString4(arcString4);
	
	
	printf("\nConcatenated string using printf format.\n");
	printf("<%s><%s><%s><%s>\n", arcString1,arcString2,
								 arcString3, arcString4);
	
	
	printf("\nConcatenated string using strcpy & strcat.\n");
		strcpy(arcCompositeString, arcString1);	/*	Copies string 1 into composite string array	*/
		strcat(arcCompositeString, arcString2);	/*	Concatenates string 2 with string1 in composite string array */
		strcat(arcCompositeString, arcString3);
		strcat(arcCompositeString, arcString4);
		
		printf("%s", arcCompositeString);
	
			printf("\n\n");
	
	system("PAUSE");
}


/*
**********************Function Definitions*********************
***************************************************************
*/


/*****************************
*	1. Funtion Print string 1
******************************/

void fnPrintString1(char arcString1[5])
{
	int nString1length;
	
	printf("\n");
	printf("Given string 1 : ");
	puts(arcString1);
	nString1length = strlen(arcString1);
	printf("String length : %2d  (including any spaces)\n", nString1length);
	
	if(nString1length == 0)
			printf("String 1 empty no characters given\n.");
			
	else if(nString1length <= arcString1[5])
			printf("String 1 size exceeded the allowed limit of 5 characters.\n");
 			
	else
			printf("String 1 size within the allowed limit of 5 characters.\n");
	
}

/*****************************
*	2. Funtion Input string 2
******************************/

void fnPrintString2(char arcString2[10])
{
	int nString2length;
	
	printf("\n");
	printf("Given string 2 : ");
	puts(arcString2);
	nString2length = strlen(arcString2);
	printf("String length : %2d (including any spaces)\n", nString2length);
	
	if(nString2length == 0)
		printf("String 2 empty no characters given.\n");
		
	else if(nString2length <= arcString2[10])
		printf("String 2 size exceeded the allowed limit of 10 characters.\n");
		
	else
		printf("String 2 size within the allowed limit of 10 characters.\n");
	
}

/*****************************
*	3. Funtion Input string 3
******************************/

void fnPrintString3(char arcString3[15])
{
	int nString3length;
	
	printf("\n");
	printf("Given string 3 : ");
	puts(arcString3);
	nString3length = strlen(arcString3);
	printf("String length : %2d (including any spaces)\n", nString3length );
	
	if(nString3length == 0)
		printf("String 3 empty no characters given.\n");
		
	else if(nString3length <= arcString3[15])
		printf("String 3 size exceeded the allowed limit of 15 characters.\n");
		
	else
		printf("String 3 size within the allowed limit of 15 characters.\n");
}

/*****************************
*	4. Funtion Input string 4
******************************/

void fnPrintString4(char arcString4[20])
{
	int nString4length;
	
	printf("\n");
	printf("Given string 4 : ");
	puts(arcString4);
	nString4length = strlen(arcString4);
	printf("String length : %2d (including any spaces)\n", nString4length);
	
	if(nString4length == 0)
		printf("String 4 empty no characters given.\n");
		
	else if(nString4length <= arcString4[20])
		printf("String 4 size exceeded the allowed limit of 20 characters.\n");
		
	else
		printf("String 4 size within the allowed limit of 20 characters.\n");
}
