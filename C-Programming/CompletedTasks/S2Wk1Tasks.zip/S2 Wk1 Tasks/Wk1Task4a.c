#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define Y 10
//void fnInputString1(char arString1[5]);
//void fnInputString2(char arString2[10]);
//void fnInputString3(char arString3[15]);
//void fnInputString4(char arString4[20]);
//void fnPrintString1(char arnString1[5]);
//void fnPrintString2(char arnString1[10]);
//void fnPrintString3(char arnString1[15]);
//void fnPrintString4(char arnString1[20]);
void printstring(char strsArray[][Y], int n);

int main(void)
{
	int n,x;
	printf("num of strings ");
	scanf("%d", &x);
		//printf("string length ");
		//scanf("%d", &Y);
	char strs[x][Y];
		//printf("Enter string \n");
	for (n=0; n <= x; n++)
	{
	printf("String %d\n", n+1);
	gets(strs[n]);
	}
	
	printf("all Strings entered \n");
	printstring(strs,n);
	
	return 0;
		
}

void printstring(char strsArray[][Y], int n)
{
	int k;
	printf("Strings are: \n");
	for (k = 0; k<n; k++)
	puts(strsArray[k]);	
}
	
	
//	char arString1[5];
//	char arString2[10];
//	char arString3[15];
//	char arString4[20];
	
//	fnInputString1(arString1);
//	fnInputString2(arString2);
//	fnInputString3(arString3);
//	fnInputString4(arString4);
//	
//	system("cls");
//	
//	fnPrintString1(arString1);
//	fnPrintString2(arString2);
//	fnPrintString3(arString3);
//	fnPrintString4(arString4);
//	
//	printf("\nConcatenated string : %4s %4s %4s %4s \n",
//								arString1, arString2, arString3, arString4);
//	printf("\n\n");
//	system("PAUSE");
//}

 

//void fnInputString1(char arString1[5])
//{
//	printf("Enter string 1 (max: 5 char including spaces): \n");
//	gets(arString1);	
//}
//
//void fnInputString2(char arString2[10])
//{
//	printf("Enter string 2 (max: 10 char including spaces): \n");
//	gets(arString2);
//}
//
//void fnInputString3(char arString3[15])
//{
//	printf("Enter string 3 (max: 15 char including spaces): \n");
//	gets(arString3);
//}
//
//void fnInputString4(char arString4[20])
//{
//	printf("Enter string 4 (max: 20 char including spaces): \n");
//	gets(arString4);
//}
//
//void fnPrintString1(char arString1[5])
//{
//	int nString1length;
//	
//	printf("\n");
//	printf("Given string 1 : ");
//	puts(arString1);
//	nString1length = strlen(arString1);
//	printf("String length : %2d \n", nString1length);
//	if(nString1length <= arString1[5] || nString1length == 0)
//		printf("String 1 size exceeded the allowed limit.\n");
//	//else if(nString1length == 0)
//	//	printf("String 1 empty no characters given.");
//	else
//		printf("String 1 size within the allowed limit.\n");
//}
//
//void fnPrintString2(char arString2[10])
//{
//	int nString2length;
//	
//	printf("\n");
//	printf("Given string 2 : ");
//	puts(arString2);
//	nString2length = strlen(arString2);
//	printf("String length : %2d \n", nString2length);
//	if(nString2length <= arString2[10])
//		printf("String 2 size exceeded the allowed limit.\n");
//	else if(nString2length == 0)
//		printf("String 2 empty no characters given.");
//	else
//		printf("String 2 size within the allowed limit.\n");
//	
//}
//
//void fnPrintString3(char arString3[15])
//{
//	int nString3length;
//	
//	printf("\n");
//	printf("Given string 3 : ");
//	puts(arString3);
//	nString3length = strlen(arString3);
//	printf("String length : %2d \n", nString3length );
//	if(nString3length <= arString3[15])
//		printf("String 3 size exceeded the allowed limit.\n");
//	else if(nString3length == 0)
//		printf("String 3 empty no characters given.");
//	else
//		printf("String 3 size within the allowed limit.\n");
//}
//
//void fnPrintString4(char arString4[20])
//{
//	int nString4length;
//	
//	printf("\n");
//	printf("Given string 4 : ");
//	puts(arString4);
//	nString4length = strlen(arString4);
//	printf("String length : %2d \n", nString4length);
//	if(nString4length <= arString4[20])
//		printf("String 4 size exceeded the allowed limit.\n");
//	else if(nString4length == 0)
//		printf("String 4 empty no characters given.");
//	else
//		printf("String 4 size within the allowed limit.\n");
//}
