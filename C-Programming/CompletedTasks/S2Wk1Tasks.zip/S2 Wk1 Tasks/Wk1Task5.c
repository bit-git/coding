/*
*  File.Wk1Task5.c
*  HCS
*
*  Created by Omer Chohan on 01/02/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Defined string length and number of strings to be entered */
#define MAX_LENGTH 10
#define NUM_OF_STRINGS 5		/*	Array starts at index zero	0-4 */

/*
*	Function prototypes to selection sort input strings
*	and print the sorted strings 2D array
*/


void fnSelectionSort(char strsArray[][MAX_LENGTH]);
void fnExchangeSort(char strsArray[][MAX_LENGTH]);
void fnPrintString(char strsArray[][MAX_LENGTH], int n);

int main(void)
{
	int nRow;
	
	char strsArray[NUM_OF_STRINGS][MAX_LENGTH];
	
			printf("\n\tWeek 1 Tutorial\n\tSummative Task 2\n\tSorting a 2D array\n\tof 5 strings.\n\n");
			printf("\nNote: Enter strings of 10 characters MAX\n");
			printf("If more characters entered, space from\nnext string will be taken.\n\n");	
			
	
		/*	Input strings	*/
		for (nRow = 0; nRow < NUM_OF_STRINGS ; nRow++)
			{
				printf("Enter string %d\n" , nRow + 1);
				
				fgets(strsArray[nRow], MAX_LENGTH, stdin);
			}
	
	
		/*	Selection Sort	*/
			fnSelectionSort(strsArray);
	
				printf("\nSelection sorted strings.");
				fnPrintString(strsArray, nRow);
		
		/* Exchange Sort	*/
			
			fnExchangeSort(strsArray);
	
				printf("\nExchange sorted strings.");
				fnPrintString(strsArray, nRow);
	
		
	
	return 0;
		
}


/*
**********************Function Definitions*********************
***************************************************************
*/



/*********************************************
*	1. Selection sort descending 
*	   the 2D array of strings
**********************************************/

void fnSelectionSort(char strsArray[NUM_OF_STRINGS][MAX_LENGTH])
{
   int i, j,  minPosition;
   char temp[MAX_LENGTH];
     
   		for(i = 0; i < NUM_OF_STRINGS - 1 ; i++)
		{
	  		minPosition = i;                 /* set min to the firt index */ 
      
	  			for(j = i + 1; j < NUM_OF_STRINGS; j++)
				{
         			if ((strcmp (strsArray[minPosition], strsArray[j])) > 0 )
					{
       					minPosition = j;
					}
      	  		}
      	  		  
					if( minPosition != i )
	  				{
							strcpy(temp,strsArray[i]);       				/* copy into temp, strsArray[i] */
         					strcpy(strsArray[i],strsArray[minPosition]); 	/* copy into strsArray[i], strsArray[minPosition] */ 
         					strcpy(strsArray[minPosition],temp);			/* copy into strsArray[minPosition],temp */
	  				}
           	     			
       	}
}



/*********************************************
*	2. Exchange sort descending 
*	   the 2D array of strings
**********************************************/

void fnExchangeSort(char strsArray[NUM_OF_STRINGS][MAX_LENGTH])
{
	int i, j;
   	char temp[MAX_LENGTH];
   	
		for(i = 0; i < NUM_OF_STRINGS - 1; i++)
		{
			for(j = i + 1; j < NUM_OF_STRINGS; j++)	
			{
					if ( strcmp( strsArray[i], strsArray[j]) < 0 )
					{
							strcpy(temp, strsArray[i]);       		/* copy into temp, strsArray[i] */
       						strcpy(strsArray[i], strsArray[j]); 	/* copy into strsArray[i], strsArray[min] */ 
   							strcpy(strsArray[j], temp);   
					}

			}	
			

		}
}


/******************************************
*	3. Print the sorted 2D array of strings
*******************************************/
   
void fnPrintString(char strsArray[][MAX_LENGTH], int nRow)
{
	int k;
	
	printf("\n");
	
		for (k = 0; k < nRow; k++)
		{
			//puts(strsArray[k]);
			printf("%s", strsArray[k]);
		}
		
}
	
	

