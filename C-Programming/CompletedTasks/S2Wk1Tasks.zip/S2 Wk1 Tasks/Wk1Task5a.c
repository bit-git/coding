/*
*  File.Wk1Task4.c
*  HCS
*
*  Created by Omer Chohan on 01/02/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Defined string length and number of strings to be entered */
#define MAX_LENGTH 10
#define NUM_OF_STRINGS 4

/*
*	Function prototypes to selection sort input strings
*	and print the sorted strings 2D array
*/
void printString(char strsArray[][MAX_LENGTH], int n);
void selectionSort(char strsArray[][MAX_LENGTH]);


int main(void)
{
	int nRow;
	
	char strsArray[NUM_OF_STRINGS][MAX_LENGTH];
	
	printf("\n\tNote: Enter strings of 10 characters MAX\n");
	printf("\tIf more characters entered, space from \n\tnext string will be taken.\n\n");	
		for (nRow=0; nRow < NUM_OF_STRINGS; nRow++)
			{
				printf("Enter string %d\n" , nRow + 1);
				
				fgets(strsArray[nRow], MAX_LENGTH, stdin);
			}
	
	
	selectionSort(strsArray);
	
	printf("Selection Sorted strings. \n");
	
	printString(strsArray, nRow);
	
	return 0;
		
}


/*
**********************Function Definitions*********************
***************************************************************
*/

/*********************************************
*	1. Selection ascending sort 
*	   the 2D array of strings
**********************************************/

void selectionSort(char strsArray[NUM_OF_STRINGS][MAX_LENGTH])
{
   int i, j, n = NUM_OF_STRINGS, min;
   char temp[MAX_LENGTH];
     
   for(i = 0; i < n - 1 ; i++) 
   	{
      min = i;                 /* set min to the firt index */ 
      
	  	for(j = i + 1; j < n; j++) 
		  {
         	if ((strcmp (strsArray[j], strsArray[min])) < 0 )
			  {
            		min = j;
         	  }
      	  }
  
      if( min != i )
	  	{
           	strcpy(temp,strsArray[i]);       		/* copy into temp, strsArray[i] */
         	strcpy(strsArray[i],strsArray[min]); 	/* copy into strsArray[i], strsArray[min] */ 
         	strcpy(strsArray[min],temp);     		/* copy into strsArray[min],temp */
       	}
    }
}

/******************************************
*	2. Print the sorted 2D array of strings
*******************************************/

void printString(char strsArray[][MAX_LENGTH], int nRow)
{
	int k;
	
	printf("\n\n");
	printf("Selection sorted strings are:\n\n");
	
		for (k = 0; k <= nRow; k++)
		{
			puts(strsArray[k]);	
		}
		
}
	
	

