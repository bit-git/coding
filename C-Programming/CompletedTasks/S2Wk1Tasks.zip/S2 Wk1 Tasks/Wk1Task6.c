/*
*	
*  File.Wk1Task6.c
*  HCS
*
*  Created by Omer Chohan on 01/02/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/

#include <stdio.h>
#include <string.h>

#define MAX_LENGTH 50


/* Define the structure */
struct employee
	{
		char	arcLName[MAX_LENGTH];
		char	arcFName[MAX_LENGTH];
		char	cGender;
		int		nAge;
		char	arcJobTitle[MAX_LENGTH];
		double	dSalary;
	};
	
	
int main(void)
{


/************************
	Instantiate Structure 
	Employee 1 using constants
*************************/

	struct employee Emp1;
	char c;
	int nID;
	
	
	printf("\n\tWeek 1 Tutorial\n\tSummative Task 6\n\tIntroduction to Structures.\n\n");


	/* 	Now add some data - use constants for now
		Note the use of a dot to access the internal data 
		variables - first a simple one */
	Emp1.nAge = 33;

	/* Now output */
	printf("\nThe employee's age is %d\n\n", Emp1.nAge);

	/* Now add some strings - need to use strcpy() */
	strcpy(Emp1.arcFName, "David D");
	strcpy(Emp1.arcLName, "Hodgkiss");
	strcpy(Emp1.arcJobTitle, "Senior Lecturer & Award Leader");
	
	/* 	That is the strings, now for the char.
		No need to use strcpy() as it is not a string */
	Emp1.cGender = 'M';		/* Note use of single quotes */

	/* ... and finally - Salary */
	Emp1.dSalary = 15851.89;

	/* Now output the lot */
	printf("\nThe employee's name is %s %s \nJob Title %s\nGender %c  Age %d\nSalary %lf\n\n",
											Emp1.arcFName, 
											Emp1.arcLName,
											Emp1.arcJobTitle,
											Emp1.cGender,
											Emp1.nAge,
											Emp1.dSalary);
											
											

/****************************************
*	
*	Instantiate Structure array
*	for three employees by user input
*
******************************************/
	
	struct employee Emp[3];
			
	/*	Input struct data	*/	
			
	for( nID = 0; nID < 3 ; nID++ )
	{
	  	printf("\nEnter employee %d details: ", nID + 1);
	   				
		printf("\nEnter employee last name : ");
	   	fgets(Emp[nID].arcLName,  MAX_LENGTH, stdin);
	   	
		printf("Enter first name : ");
	   	
		/* use gets to print first name next to last name. fgets prints in next line */
		gets(Emp[nID].arcFName);
	   	
		printf("Enter job title : ");
	   	fgets(Emp[nID].arcJobTitle, MAX_LENGTH, stdin);
		printf("Enter gender M/F : ");
	   	scanf(" %c", &Emp[nID].cGender);  
	   	printf("Enter age : ");
	  	scanf("%d", &Emp[nID].nAge);
	   	printf("Enter salary : ");
	   	scanf("%lf", &Emp[nID].dSalary);
		
		fflush(stdin);	/*	To flush keyboard buffer	*/
				
	}
							
	/*	Now print the struct input	*/		
			
	for( nID = 0 ; nID < 3 ; nID++)
	{
		printf(" The employee %d's name is %s %s Job Title %s Gender %c  Age %d\n Salary %0.2lf\n\n",
											nID +1,
											Emp[nID].arcFName, 
											Emp[nID].arcLName,
											Emp[nID].arcJobTitle,
											Emp[nID].cGender,
											Emp[nID].nAge,
											Emp[nID].dSalary);

	}
	
	
	system("PAUSE");
								
	return 0;
	
}
