/*
*	Starting with Wk12L2Ex7.c
*	Extend the code such that it declares three employees, 
*	asks for relevant data to be input by the user and then outputs a suitable summary.
*
*  File.Wk1Task6.c
*  HCS
*
*  Created by Omer Chohan on 01/02/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/

#include <stdio.h>
#include <string.h>

#define MAX_LENGTH 50

/* Define the structure */
struct employee
	{
		char	arcLName[MAX_LENGTH];
		char	arcFName[MAX_LENGTH];
		char	cGender;
		int		nAge;
		char	arcJobTitle[MAX_LENGTH];
		double	dSalary;
	};
	
	
int main(void)
{


/************************
	Instantiate Structure 
	Employee 1
*************************/
	struct employee Emp1;

	printf("Week 12 Lecture 2\nExample 7\nIntroduction to Structures\n\n");

	/* 	Now add some data - use constants for now
		Note the use of a dot to access the internal data 
		variables - first a simple one */
	Emp1.nAge = 33;

	/* Now output */
	printf("\nThe employee's age is %d\n\n", Emp1.nAge);

	/* Now add some strings - need to use strcpy() */
	strcpy(Emp1.arcFName, "David D");
	strcpy(Emp1.arcLName, "Hodgkiss");
	strcpy(Emp1.arcJobTitle, "Senior Lecturer & Award Leader");
	
	/* 	That is the strings, now for the char.
		No need to use strcpy() as it is not a string */
	Emp1.cGender = 'M';		/* Note use of single quotes */

	/* ... and finally - Salary */
	Emp1.dSalary = 15851.89;

	/* Now output the lot */
	printf("\nThe employee's name is %s %s\nJob Title %s\nGender %c  Age %d\nSalary %lf\n\n",
											Emp1.arcFName, 
											Emp1.arcLName,
											Emp1.arcJobTitle,
											Emp1.cGender,
											Emp1.nAge,
	
											Emp1.dSalary);
											

/************************
*	Instantiate Structure 
*	Employee 2
*************************/
	
	struct employee Emp2;
	
	printf("Enter Employee 2 last name	: ");
	scanf("%s", &Emp2.arcFName);
	printf("Enter Employee 2 first name	: ");
	scanf("%s", &Emp2.arcLName);	
	printf("Enter Employee 2 job title	: ");
	scanf("%s", &Emp2.arcJobTitle);
	printf("Enter Employee 2 gender		: ");
	scanf(" %c", &Emp2.cGender);
	printf("Enter Employee 2 age		: ");
	scanf("%d", &Emp2.nAge);
	printf("Enter Employee 2 salary		: ");
	scanf("%lf", &Emp2.dSalary);
	
	printf("\nThe employee's name is %s %s\nJob Title %s\nGender %c  Age %d\nSalary %l0.2f\n\n",
									Emp2.arcFName, 
									Emp2.arcLName,
									Emp2.arcJobTitle,
									Emp2.cGender,
									Emp2.nAge,
									Emp2.dSalary);
		
		
/************************
*	Instantiate Structure 
*	Employee 3
*************************/

	struct employee Emp3;
	
	printf("Enter Employee 3 last name	: ");
	scanf("%s", &Emp3.arcFName);
	printf("Enter Employee 3 first name	: ");
	scanf("%s", &Emp3.arcLName);	
	printf("Enter Employee 3 job title	: ");
	scanf("%s", &Emp3.arcJobTitle);
	printf("Enter Employee 3 gender		: ");
	scanf(" %c", &Emp3.cGender);
	printf("Enter Employee 3 age		: ");
	scanf("%d", &Emp3.nAge);
	printf("Enter Employee 3 salary		: ");
	scanf("%lf", &Emp3.dSalary);
	
	printf("\nThe employee's name is %s %s\nJob Title %s\nGender %c  Age %d\nSalary %0.2lf\n\n",
									Emp3.arcFName, 
									Emp3.arcLName,
									Emp3.arcJobTitle,
									Emp3.cGender,
									Emp3.nAge,
									Emp3.dSalary);
									
/************************
*	Instantiate Structure 
*	Employee 4
*************************/
	
	struct employee Emp4;
	
	printf("Enter Employee 4 last name	: ");
	scanf("%s", &Emp4.arcFName);
	printf("Enter Employee 4 first name	: ");
	scanf("%s", &Emp4.arcLName);	
	printf("Enter Employee 4 job title	: ");
	scanf("%s", &Emp4.arcJobTitle);
	printf("Enter Employee 4 gender		: ");
	scanf(" %c", &Emp4.cGender);
	printf("Enter Employee 4 age		: ");
	scanf("%d", &Emp4.nAge);
	printf("Enter Employee 4 salary		: ");
	scanf("%lf", &Emp4.dSalary);
	
	printf("\nThe employee's name is %s %s\nJob Title %s\nGender %c  Age %d\nSalary %0.2lf\n\n",
									Emp4.arcFName, 
									Emp4.arcLName,
									Emp4.arcJobTitle,
									Emp4.cGender,
									Emp4.nAge,
									Emp4.dSalary);
										
	return 0;
}
