/*
*  File.Wk2Task2.c
*  HCS
*
*  Created by Omer Chohan on 10/02/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Structure definitions from header file */
#include "Wk2Task2.h"


int main(void)
{
	/**** Create two instances of strPerson Pers1, Pers2 ****/
	
	struct strPerson Pers1, Pers2;   
	
	/**** Using constants for pers 1 ****/
	
	strcpy(Pers1.arcFirstName,"David");
	strcpy(Pers1.arcMiddleName, "Dennis");
	strcpy(Pers1.arcLastName,"Hodgkiss");
	Pers1.cSex = 'M'; 
	Pers1.strDOB.nDay = 13;
	Pers1.strDOB.nMonth = 05;
	Pers1.strDOB.nYear = 2010;

	/**** Using constants for pers 2 ****/
	
	strcpy(Pers2.arcFirstName,"James");
	strcpy(Pers2.arcMiddleName,"");
	strcpy(Pers2.arcLastName,"McCarren");
	Pers2.cSex = 'M'; 
	Pers2.strDOB.nDay = 18;
	Pers2.strDOB.nMonth = 06;
	Pers2.strDOB.nYear = 2011;

	/*********Display Pers 1 *********/
	
	printf("\n\n\n\tPerson 1\n");
	printf("\tFirst Name : %s \n\tMiddle Name : %s \n\tLast Name : %s \n", 
             Pers1.arcFirstName,Pers1.arcMiddleName,Pers1.arcLastName);
	printf("\tSex : %c \n\tD.O.B : %d/%d/%d ", 
             Pers1.cSex,Pers1.strDOB.nDay,Pers1.strDOB.nMonth,Pers1.strDOB.nYear);

             printf("\n\n");
    /*********Display Pers 2 *********/
    
	printf("\n\tPerson 2\n");
	printf("\tFirst Name : %s \n\tMiddle Name : %s \n\tLast Name : %s \n",
             Pers2.arcFirstName , Pers2.arcMiddleName , Pers2.arcLastName);
	printf("\tSex : %c \n\tD.O.B : %d/%d/%d \n",
             Pers2.cSex , Pers2.strDOB.nDay , Pers2.strDOB.nMonth , Pers2.strDOB.nYear);
	
    printf("\n\n");
    
    system("PAUSE");

	return 0;
	
}
