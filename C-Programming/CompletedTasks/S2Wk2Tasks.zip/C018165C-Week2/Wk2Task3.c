/*
*  File.Wk2Task3.c
*  HCS
*
*  Created by Omer Chohan on 10/02/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Structure definitions from header file */
#include "Wk2Task3.h"


int main(void)
{
	/**** Create two instances of strPerson Pers1, Pers2 ****/
	
	struct strPerson Pers1, Pers2;   
	
	/**** Assigning data to Person 1 ****/
	printf("\n\n\tEnter person 1 detials :\n ");
	printf("\tFirst Name : ");
	fgets(Pers1.arcFirstName, MAX_LENGTH, stdin);
	printf("\tMiddle Name : ");
	gets(Pers1.arcMiddleName);
	printf("\tLast Name : ");
	fgets(Pers1.arcLastName, MAX_LENGTH, stdin);
	printf("\tSex : ");
	scanf(" %c", &Pers1.cSex); 
	printf("\tDate of Birth (DD/MM/YYYY);\n\tDay (1-31) : ");
	scanf("%d",&Pers1.strDOB.nDay);
	printf("\tMonth (1-12) : ");
	scanf("%d",&Pers1.strDOB.nMonth);
	printf("\tYear : ");
	scanf("%d",&Pers1.strDOB.nYear);
	
	fflush(stdin); /* Flush keyboard buffer */

	/**** Assigning data to Person 2 ****/
	printf("\n\n\tEnter person 2 detials :\n ");
	printf("\tFirst Name : ");
	fgets(Pers2.arcFirstName, MAX_LENGTH, stdin);
	printf("\tMiddle Name : ");
	gets(Pers2.arcMiddleName);
	printf("\tLast Name : ");
	fgets(Pers2.arcLastName, MAX_LENGTH, stdin);
	printf("\tSex : ");
	scanf(" %c", &Pers2.cSex); 
	printf("\tDate of Birth (DD/MM/YYYY);\n\tDay (1-31) : ");
	scanf("%d",&Pers2.strDOB.nDay);
	printf("\tMonth : ");
	scanf("%d",&Pers2.strDOB.nMonth);
	printf("\tYear : ");
	scanf("%d",&Pers2.strDOB.nYear);
	

    /*********Display Pers 1 *********/
	
	printf("\n\n\n\tPerson 1\n");
	printf("\tFirst Name : %s \tMiddle Name : %s \n\tLast Name : %s", 
             Pers1.arcFirstName,Pers1.arcMiddleName,Pers1.arcLastName);
	printf("\tSex : %c \n\tD.O.B : %d/%d/%d ", 
             Pers1.cSex,Pers1.strDOB.nDay,Pers1.strDOB.nMonth,Pers1.strDOB.nYear);

             printf("\n\n");
    /*********Display Pers 2 *********/
    
	printf("\n\tPerson 2\n");
	printf("\tFirst Name : %s \tMiddle Name : %s \n\tLast Name : %s",
             Pers2.arcFirstName , Pers2.arcMiddleName , Pers2.arcLastName);
	printf("\tSex : %c \n\tD.O.B : %d/%d/%d \n",
             Pers2.cSex , Pers2.strDOB.nDay , Pers2.strDOB.nMonth , Pers2.strDOB.nYear);
	
    printf("\n\n");
    
    system("PAUSE");
	
    return 0;
    
}
