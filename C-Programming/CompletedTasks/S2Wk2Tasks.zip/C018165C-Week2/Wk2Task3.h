/*
*  File.Wk2Task3.h
*  HCS
*
*  Created by Omer Chohan on 10/02/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/


#ifndef Wk2Task3_h_ 
#define Wk2Task3_h_ 
#define MAX_LENGTH 50

/**** Define the structures ****/
/**** Define the date structure ****/

struct strDate
{
	int	nDay;
	int	nMonth;
	int	nYear;
};

/**** Define the person structure ****/

struct strPerson
{
	char	arcFirstName[MAX_LENGTH];
	char	arcMiddleName[MAX_LENGTH];
	char	arcLastName[MAX_LENGTH];
	char	cSex;
	struct	strDate strDOB;
};

#endif
