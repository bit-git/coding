/*
*  File.Wk2Task4.c
*  HCS
*
*  Created by Omer Chohan on 10/02/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Structure definitions from header file */
#include "Wk2Task4.h"


int main(void)
{
	/**** Create array of 5 instances of strPerson Pers[] ****/
	
	struct strPerson Pers[5] , sPers;   
	int i;
	FILE *file1;
	
	/**** Assigning data to struct person ****/
	
	for(i = 0; i < 5 ; i++ )
   {	
   		fflush(stdin);
   		
   		printf("\n");
        printf("\tEnter person %d detais : \n", i + 1);
	    printf("\tFirst Name : ");
		fgets(Pers[i].arcFirstName, MAX_LENGTH, stdin);
		printf("\tMiddle Name : ");
		gets(Pers[i].arcMiddleName);
		printf("\tLast Name : ");
		fgets(Pers[i].arcLastName, MAX_LENGTH, stdin);
		printf("\tSex : ");
		scanf(" %c", &Pers[i].cSex); 
		printf("\tDate of Birth (DD/MM/YYYY); \n\tDay (1-31) : ");
		scanf("%d", &Pers[i].strDOB.nDay);
		printf("\tMonth (1-12) : ");
		scanf("%d", &Pers[i].strDOB.nMonth);
		printf("\tYear : ");
		scanf("%d", &Pers[i].strDOB.nYear);
	}
	
	/*** Write to txt file ***/ 
	 
	
	file1 = fopen("Task4.txt", "w");        /*** Open file to write  ***/

	for(i = 0; i < 5; i++ )
	{
	  fprintf(file1,"%s %s %s %c %d/%d/%d \n",
                        Pers[i].arcFirstName , Pers[i].arcMiddleName , Pers[i].arcLastName,
                        Pers[i].cSex , 
                        Pers[i].strDOB.nDay , Pers[i].strDOB.nMonth , Pers[i].strDOB.nYear );
 	}
 	
	fclose(file1); 		/*** Must close file in the end ***/


	/*** Displaying Person ***/
	
	for(i=0 ; i < 5 ; i++)
	{
		printf("\n\n\tPerson %d\n", i + 1);
		printf("\tFirst Name : %s \tMiddle Name : %s \n\tLast Name : %s",
                        Pers[i].arcFirstName , Pers[i].arcMiddleName , Pers[i].arcLastName);
		printf("\tSex : %c \n\tD.O.B : %d/%d/%d \n", 
                        Pers[i].cSex , 
                        Pers[i].strDOB.nDay , Pers[i].strDOB.nMonth , Pers[i].strDOB.nYear);
	}
    
    
	printf("\n\n");
	
    system("PAUSE");
    
	return 0;
	
}

  
