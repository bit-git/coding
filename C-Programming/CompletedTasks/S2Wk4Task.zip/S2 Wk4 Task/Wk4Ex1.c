#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linkedlist.h"		/* conatins structure definition */

/* 	Function Prototypes 
	Note that variable names have been removed as they are 
	not actually required - they are optional
*/
//int fnTotalList(struct strPerson *);
 strPerson *fnAddItem( strPerson *);
void fnPrintList( strPerson *);
int fnMenu(void);
 strPerson *fnRemoveEndItem( strPerson *);
 strPerson *fnRemoveStartItem( strPerson *);
void fnSearchList( strPerson *);
strPerson *fnSearchandDel( strPerson *);

int main(int argc, char *argv[])
{
 	 strPerson *ptrHead = NULL;
	 strPerson *ptrTemp = NULL;
 	 int nChoice = 0;
	 int nRun = 1;
	 char str[20];
	
	 while(nRun)
	 {
	 	 nChoice = fnMenu();
		 
		 switch(nChoice)
		 {
		     case 1:	/* Add an item */
							
							ptrHead = fnAddItem(ptrHead);
			  		 		break;

			  case 2:	/* Print the list */
							fnPrintList(ptrHead);
							//printf("The list total is %d\n", fnTotalList(ptrHead));
			  		 		break;

			  case 3:	// Remove an end item 
			  				ptrHead = fnRemoveEndItem(ptrHead);
							

							break;

			  case 4:	// Remove a start item 
			  				ptrHead = fnRemoveStartItem(ptrHead);
							
							break;

			  case 5:	// Search the list 
			  				
			  				fnSearchList(ptrHead);
							break;
							
			  case 6:  // search name and delete
                            ptrHead = fnSearchandDel(ptrHead);
							break;

			  case 7:	// Exit program 
							nRun = 0;	/* set to zero to stop the while loop */
			  		 		break;
		}
	}
 	
  	return 0;
}

strPerson *fnAddItem( strPerson *ptrH)
{
	 strPerson *ptrTemp = NULL;

	if(ptrH == NULL)
	{
		/* Special case - list empty */
		ptrH = ( strPerson *)malloc(sizeof( strPerson));
		if(ptrH == NULL)
		{
			printf("Adding to empty list - malloc has failed\n");
			exit(1);
		}
		/* malloc has worked - set values */
		fflush(stdin);
	    printf(" Enter First Name : ");
		gets(ptrH->arcFirstName);
		printf(" Enter Middle Name : ");
		gets(ptrH->arcMiddleName);
		printf(" Enter Last Name : ");
		gets(ptrH->arcLastName);
		printf(" Sex : ");
		gets(&ptrH->cSex); 
		printf(" Enter Date of Birth , Day : ");
		scanf("%d",&ptrH->strDOB.nDay);
		printf(" month : ");
		scanf("%d",&ptrH->strDOB.nMnth);
		printf(" Year : ");
		scanf("%d",&ptrH->strDOB.nYear);
		ptrH->ptrNext = NULL;		/* This is important as it signals
												the last node within the list */
	}
	else
	{
		/* There are items already in the list
			need to locate the end - use a while loop
			to step through looking for ptrNext to
			equal NULL */
		
		ptrTemp = ptrH;	/* Use a temp pointer */
		while(ptrTemp->ptrNext != NULL)
		{
			/* As ptrNext has a value there is a node
				hanging off it */
			ptrTemp = ptrTemp->ptrNext;
		}
		/* ptrTemp is now pointing at the last node1
			within the list
			Now, create a new node that "hangs off"
			ptrNext within this last node  */

			ptrTemp->ptrNext = ( strPerson *)malloc(sizeof( strPerson));
			if(ptrTemp->ptrNext == NULL)
			{
				printf("Adding to end of list - malloc has failed\n");
				exit(1);
			}
			fflush(stdin);
	    printf(" Enter First Name : ");
		gets(ptrTemp->ptrNext->arcFirstName);
		printf(" Enter Middle Name : ");
		gets(ptrTemp->ptrNext->arcMiddleName);
		printf(" Enter Last Name : ");
		gets(ptrTemp->ptrNext->arcLastName);
		printf(" Sex : ");
		gets(&ptrTemp->ptrNext->cSex); 
		printf(" Enter Date of Birth , Day : ");
		scanf("%d",&ptrTemp->ptrNext->strDOB.nDay);
		printf(" month : ");
		scanf("%d",&ptrTemp->ptrNext->strDOB.nMnth);
		printf(" Year : ");
		scanf("%d",&ptrTemp->ptrNext->strDOB.nYear);
			ptrTemp->ptrNext->ptrNext = NULL;
	}

	return ptrH;	/* This is really only needed when adding the first item
							to the list - but have to do it in all cases to avoid
							error messages */
}

int fnMenu(void)
{
 	 int nChoice;
 	 
 	 printf("Choices menu\n\n");
	 printf("1.\tAdd an item\n");
	 printf("2.\tPrint list\n");
	 printf("3.\tRemove an end item\n");
	 printf("4.\tRemove a start item\n");
	 printf("5.\tSearch for a name value\n");
	 printf("6.\tSearch for a name and delete \n");
	 printf("7.\tQuit\n\n");
	 printf("Please enter a choice :");
	 scanf("%d", &nChoice);

	 return nChoice;
}

void fnPrintList( strPerson *ptrT)
{
	 strPerson *ptrH = ptrT; 
	if(!ptrH)
	{
		printf("\n\n\tEmpty list\n");
	}
	else
	{
		while(ptrH)
		{
			printf("\n\n\n Person   \n");
			printf(" First Name : %s \n Middle Name : %s \n Last Name : %s \n",ptrH->arcFirstName , ptrH->arcMiddleName , ptrH->arcLastName);
		printf(" Sex : %c \n D.O.B : %d / %d / %d ", ptrH->cSex , ptrH->strDOB.nDay , ptrH->strDOB.nMnth , ptrH->strDOB.nYear);
			ptrH = ptrH->ptrNext;
		}
		printf("\nEnd of list\n\n");
	}

}


strPerson *fnRemoveEndItem( strPerson *ptrH)
{
	/*	There are two special cases ...
		1. When the list is empty
		2. When there is only one node within the list
	*/
	 strPerson *ptrTemp = NULL;

	if(!ptrH)
	{
		// The list is empty 
		printf(" The list is EMPTY \n");		  
	}
	else if(ptrH->ptrNext == NULL)
	{
		/*	There is only one node in the list
			as ptrNext within the first node
			is NULL */
		
		printf(" Only 1 item to remove "); 
		//free(ptrH);				 	This releases the memory allocated
									/*by malloc() back to the heap */
		
		ptrH = NULL;			/*	As this was the last item to remove
								/*	need to return NULL so that ptrHead
									is set to NULL  */
	}
	else
	{
		/*	There are more than one nodes in the list,
			need to step through to find the last but
			one node */
		
		ptrTemp = ptrH;
		while(ptrTemp->ptrNext->ptrNext)
		{
			ptrTemp = ptrTemp->ptrNext;
		}

		/*	ptrTemp is now pointing to the last but
			one node so can delete the last one */
		
		
		free(ptrTemp->ptrNext);
		ptrTemp->ptrNext = NULL;	/* Set to NULL as this is 
									   now the last node
									*/
	}

	return ptrH;
}



 strPerson *fnRemoveStartItem( strPerson *ptrH)
{
	 strPerson *ptrTemp = NULL;

	if(!ptrH)
	{
		//	Empty list 
		printf(" Nothing to remove list is empty \n");
		return ptrH;
	}
	else
	{
		ptrTemp = ptrH->ptrNext;
			free(ptrH);
		return ptrTemp;
	}
}


void fnSearchList( strPerson *ptrH)
{
	 strPerson *ptrTemp = ptrH;
	int nCount = 0;
	char str[50];
	printf("Please enter the search ( first name )  : ");
	fflush(stdin);	
	gets(str);

	if(!ptrH)
	{
		// Empty List 
		printf("\n\nEmpty List \n\n");
	}
	else
	{
		while(ptrTemp)
		{
			

			if(strcmp(ptrTemp->arcFirstName,str) == 0)
			{
				printf("The value %s has been located\n", ptrTemp->arcFirstName);
				nCount++;
			}
			ptrTemp = ptrTemp->ptrNext;
		}

		if(!nCount)
			printf("\t\tValue not found within the list\n");
		else
			printf("\t\tA total of %d names were found\n", nCount);
	}	
	
}



strPerson *fnSearchandDel( strPerson *ptrH)
{
	 strPerson *ptrTemp = ptrH;
	 strPerson *prev = ptrH;      // to keep track of previous node
	int nCount = 0;
	char str[50];
	printf("Please enter the search ( first name ) which you want to remove : ");
	fflush(stdin);	
	gets(str);

	if(!ptrH)
	{
		// Empty List 
		printf("\n\nEmpty List \n\n");
	}
	else
	{
		while(ptrTemp)
		{
			

			if(strcmp(ptrTemp->arcFirstName,str) == 0)  // if name matches
			{
				printf("The value %s has been located\n", ptrTemp->arcFirstName);
				nCount++;
				if(ptrTemp == ptrH )        // if its the start node
				{
					ptrH = ptrTemp->ptrNext;    // point the header to the next node
					break;
				}
				else
				{
					prev->ptrNext = ptrTemp->ptrNext;    // point the previous link to the next link deleting the current 
					break;
				}
			}
			prev = ptrTemp;
			ptrTemp = ptrTemp->ptrNext;
		}

		if(!nCount)
			printf("\t\tValue not found within the list\n");
		
	}	
	return ptrH;
	
}

/*
int fnTotalList(struct strPerson *ptrH)
{
	struct strPerson *ptrTemp = ptrH;
	int nTotal = 0;

	if(ptrTemp)
	{
		while(ptrTemp)
		{
			nTotal += ptrTemp->nVal;
			ptrTemp = ptrTemp->ptrNext;
		}
	}

	return nTotal;
} */  
