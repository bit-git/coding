/*	linkedlist.h
	Structure definition
*/
// person.h

#ifndef linkedlist_h_ 
#define linkedlist_h_ 


/* Define the structures */
typedef struct strDate strDate;
 struct strDate
{
	int	nDay;
	int	nMnth;
	int	nYear;
};

 typedef struct strPerson strPerson;
 struct strPerson
{
	char	arcFirstName[50];
	char	arcMiddleName[50];
	char	arcLastName[50];
	char	cSex;
	strDate strDOB;
    strPerson *ptrNext;
};

              /* Dont forget the semicolon */
#endif
		  		  
