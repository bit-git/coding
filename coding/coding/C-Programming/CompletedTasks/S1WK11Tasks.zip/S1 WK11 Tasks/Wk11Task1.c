////
////  Wk11Task1.c
////  HCS
////
////  Created by Omer Chohan on 09/12/2013.
////  Copyright (c) 2013 Staffordshire University. All rights reserved.
////
//
//#include <stdio.h>
//
//int main(void)
//{
//	int nInputVal, nMin, nMax, nCount;
//    
//	nCount = 0;
//	nMin = 9999;
//	nMax = 0;
//	nInputVal = 0;
//    
//	while(nInputVal != -9999)
//	{
//		printf("Input an integer, -9999 to end : ");
//		scanf("%d", &nInputVal);
//        
//		if(nInputVal > 150)
//		{
//			nCount++;
//			if(nInputVal > nMax) nMax = nInputVal;
//			if(nInputVal < nMin) nMin = nInputVal;
//		}
//        
//	} /* End of while loop */
//    
//	if(nCount > 0)
//	{
//		printf("Number of values greater than 150 is %d\n",nCount);
//		printf("The maximum value was %d\n", nMax);
//		printf("The minium value was %d\n", nMin);
//	}
//	else
//		printf("No values over 150\n\n");
//    
//	return 0;
//}
