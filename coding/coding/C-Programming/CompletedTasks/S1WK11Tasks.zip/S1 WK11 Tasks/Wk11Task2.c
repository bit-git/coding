////
////  Wk11Task2.c
////  HCS
////
////  Created by Omer Chohan on 09/12/2013.
////  Copyright (c) 2013 Staffordshire University. All rights reserved.
////
//
//
//#include <stdio.h>
//
//int main(void)
//{
//	int nInputVal, nMin, nMax, nCount,nCount;
//    nCount = -1; // To count how many numbers entered. Set to -1 so it does not count -9999 to end
//	nCount = 0;
//	nMin = 999;
//	nMax = 0;
//	nInputVal = 0;
//    
//	while(nInputVal != -9999)
//	{
//		printf("Input an integer, -9999 to end : ");
//		scanf("%d", &nInputVal);
//        
//        if(nInputVal >= 150 && nInputVal <= 300)
//        {
//			if(nInputVal <= nMin) nMin = nInputVal;
//			if(nInputVal >= nMax) nMax = nInputVal;
//			nCount++;
//		}
//        
//        nCount++;
//        
//	} /* End of while loop */
//    
//	if(nCount > 0)
//	{
//		printf("Number of values in range 150 - 300 inclusive is %d\n",nCount);
//		printf("The minimum value within the range was %d\n", nMin);
//        printf("The maximum value within the range was %d\n", nMax);
//        printf("Total numbers entered is %d\n",nCount);
//	}
//	else
//		printf("No values over 150\n\n");
//    
//	return 0;
//}
