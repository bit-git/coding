////
////  Wk11Task3.c
////  HCS
////
////  Created by Omer Chohan on 09/12/2013.
////  Copyright (c) 2013 Staffordshire University. All rights reserved.
////
//
//
//#include <stdio.h>
//
//int main(void)
//{
//	int nInputVal, nMinmid, nMaxmid,nMinhigh, nMaxhigh, nCountmid,nCounthigh, nCount;
//    
//    nCount = -1; // Counts how many numbers entered. Set to -1 so it does not count -9999 to end
//    nCountmid = 0; // Mid range counter
//    nCounthigh = 0; // High range counter
//	
//    nMinmid = 300;
//	nMaxmid = 0;
//	nMinhigh = 500 ;
//    nMaxhigh = 0;
//    nInputVal = 0;
//    
//	while(nInputVal != -9999)
//	{
//		printf("Input an integer, -9999 to end : ");
//		scanf("%d", &nInputVal);
//        
//        if(nInputVal >= 150 && nInputVal <= 300)
//        {
//			if(nInputVal <= nMinmid) nMinmid = nInputVal;
//			if(nInputVal >= nMaxmid) nMaxmid = nInputVal;
//			nCountmid++;
//		}
//        
//        if(nInputVal >= 301 && nInputVal <= 500)
//        {
//			if(nInputVal <= nMinhigh) nMinhigh = nInputVal;
//			if(nInputVal >= nMaxhigh) nMaxhigh = nInputVal;
//			nCounthigh++;
//        }
//        
//        nCount++;
//        
//    }/* End of while loop */
//    
//    if(nCountmid > 0 || nCounthigh > 0)
//    
//    //	if(nCountmid > 0)
//    //	{
//    //		printf("Number of values greater than 150 and less 300 is %d\n",nCountmid);
//    //		printf("The maximum value was %d\n", nMaxmid);
//    //		printf("The minimum value was %d\n", nMinmid);
//    //
//    //	}
//    //	if(nCounthigh > 0)
//    //	{
//    //		printf("Number of values greater than 301 and less 500 is %d\n",nCounthigh);
//    //		printf("The maximum value was %d\n", nMaxhigh);
//    //		printf("The minimum value was %d\n", nMinhigh);
//    //	}
//	else
//		printf("No values over 150\n");
//    printf("Total numbers entered is %d\n",nCount);
//    
//	return 0;
//}
//
