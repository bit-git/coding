//
//  Wk11Task4.c
//  HCS
//
//  Created by Omer Chohan on 09/12/2013.
//  Copyright (c) 2013 Staffordshire University. All rights reserved.
//


#include <stdio.h>


int main(void)
{
	int nInputVal, 							// Variable for user input
		nR1Min, nR1Max,						// Variables to store minimum and maximum value in the Range 1
		nR2Min, nR2Max,						// Variables to store minimum and maximum value in the Range 2
		nR3Min, nR3Max, 					// Variables to store minimum and maximum value in the Range 3
		nCountlow,nCountmid,nCounthigh, 	// Counters for values entered in each range
    
    	nCount = -1; 						// Counts how many values entered. Set to -1 so it does not count -9999 as value 
		nCountlow = 0; 						// Low range counter
    	nCountmid = 0; 						// Mid range counter
    	nCounthigh = 0; 					// High range counter
    
    	nR1Min = -120;
    	nR1Max = 0;
    	nR2Min = 300;
		nR2Max = 0;
		nR3Min = 500 ;
    	nR3Max = 0;
   		nInputVal = 0;
    
    	printf ("Enter an integer between three set ranges: \n\n");
    	printf("-120 to -10 \t 150 to 300\t 301 to 500 \n");
    	printf("(All values are inclusive.)\n\n");
    
    
	while(nInputVal != -9999)
	{
		printf("Input an integer, -9999 to end : ");
		scanf("%d", &nInputVal);
        
        if(nInputVal >= -120 && nInputVal <= -10) 
        {
			if(nInputVal >= nR1Min) nR1Min = nInputVal;
			if(nInputVal <= nR1Max) nR1Max = nInputVal;
			nCountlow++;
		}
        
        if(nInputVal >= 150 && nInputVal <= 300)
        {
			if(nInputVal <= nR2Min) nR2Min = nInputVal;
			if(nInputVal >= nR2Max) nR2Max = nInputVal;
			nCountmid++;
		}
        
        if(nInputVal >= 301 && nInputVal <= 500)
        {
			if(nInputVal <= nR3Min) nR3Min = nInputVal;
			if(nInputVal >= nR3Max) nR3Max = nInputVal;
			nCounthigh++;
        }
        
        nCount++;
        
    }	/* End of while loop */
    
    
    if(nCountlow > 0)
    {
        printf("\nNumber of values in range -10 to -120 is %d\n",nCountlow);
        printf("The maximum value was %d\n", nR1Min);
        printf("The minimum value was %d\n", nR1Max);
    }
    
	if(nCountmid > 0)
	{
		printf("\nNumber of values greater than 150 and less 300 is %d\n",nCountmid);
		printf("The maximum value was %d\n", nR2Max);
		printf("The minimum value was %d\n", nR2Min);
    }
    
	if(nCounthigh > 0)
	{
		printf("\nNumber of values greater than 301 and less 500 is %d\n",nCounthigh);
		printf("The maximum value was %d\n", nR3Max);
		printf("The minimum value was %d\n\n", nR3Min);
	}
	
    else
    
    	printf("No values over 150\n\n");
    	
    	printf("Total values entered is %d\n\n",nCount);
    
	return 0;
}

