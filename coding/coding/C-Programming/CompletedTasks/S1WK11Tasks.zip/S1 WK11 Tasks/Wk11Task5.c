//
//  Wk11Task5.c
//  HCS
//
//  Created by Omer Chohan on 15/12/2013.
//  Copyright (c) 2013 Staffordshire University. All rights reserved.
//

#include <stdio.h>


int main(void)
{
    int nInputVal,  					// Variable for user input
    	nR1Min, nR1Max, 				// Variables to store minimum and maximum value in the Range 1
    	nR2Min,nR2Max,  				// Variables to store minimum and maximum value in the Range 2
    	nR3Min, nR3Max, 				// Variables to store minimum and maximum value in the Range 3
    	
    	nRange1Min, nRange1Max, 
		nRange2Min, nRange2Max, 
		nRange3Min, nRange3Max, 		// Set 3 user defined ranges

    	nCount = -1,    				// Counts how many numbers entered. Set to -1 so it does not count -9999 as value
		nCountR1 = 0,   				// Counter for values entered in Range 1
    	nCountR2 = 0,   				// Counter for values entered in Range 2
    	nCountR3 = 0;   				// Counter for values entered in Range 3
    
        
		printf("Specify three different ranges.\n\n");
	
		printf("Minimum Value for 1st range:");
		scanf("%d", &nRange1Min);
		printf("Maximum Value for 1st range:");
    	scanf("%d", &nRange1Max);
    	printf("Range 1 fixed at: [%d] to [%d]\n\n", nRange1Min, nRange1Max);
	
		printf("Minimum Value for 2nd range:");
		scanf("%d", &nRange2Min);
		printf("Maximum Value for 2nd range:");
		scanf("%d", &nRange2Max);
		printf("Range 2 fixed at: [%d] to [%d]\n\n", nRange2Min, nRange2Max);
    	
		printf("Minimum Value for 3rd range:");
    	scanf("%d", &nRange3Min);
		printf("Maximum Value for 3rd range:");
		scanf("%d", &nRange3Max);
	    printf("Range 3 fixed at: [%d] to [%d]\n\n", nRange3Min, nRange3Max);
	
    	nR1Min = nRange1Min;
    	nR1Max = 0;
    	nR2Min = nRange2Max;
		nR2Max = 0;
		nR3Min = nRange3Max;
    	nR3Max = 0;
    	nInputVal = 0;
    
    while(nInputVal != -9999)
	{
		printf("Input an integer within the three specified ranges, -9999 to end : ");
		scanf("%d", &nInputVal);
        
        if((nInputVal >= nRange1Min) && (nInputVal <= nRange1Max))
        {
			if(nInputVal >= nR1Min) nR1Min = nInputVal;
			if(nInputVal <= nR1Max) nR1Max = nInputVal;
			nCountR1++;
		}
        
        if((nInputVal >= nRange2Min) && (nInputVal <= nRange2Max))
        {
			if(nInputVal <= nR2Min) nR2Min = nInputVal;
			if(nInputVal >= nR2Max) nR2Max = nInputVal;
			nCountR2++;
		}
        
        if(nInputVal >= nRange3Min && nInputVal <= nRange3Max)
        {
			if(nInputVal <= nR3Min) nR3Min = nInputVal;
			if(nInputVal >= nR3Max) nR3Max = nInputVal;
			nCountR3++;
        }
        
        nCount++;
        
    }/* End of while loop */
    
    if(nCountR1 > 0)
    {
        printf("\nNumber of values in range [%d] to [%d] is: %d\n",nRange1Min,nRange1Max, nCountR1);
        printf("The maximum value was %d\n", nR1Min);
        printf("The minimum value was %d\n", nR1Max);
    }
    
	if(nCountR2 > 0)
	{
		printf("\nNumber of values in range [%d] to [%d] is: %d\n",nRange2Min, nRange2Max, nCountR2);
		printf("The maximum value was %d\n", nR2Max);
		printf("The minimum value was %d\n", nR2Min);
    }
    
	if(nCountR3 > 0)
	{
		printf("\nNumber of values in range [%d] to [%d] is: %d\n",nRange3Min, nRange3Max, nCountR3);
		printf("The maximum value was %d\n", nR3Max);
		printf("The minimum value was %d\n", nR3Min);
	}
    
    else
        printf("No values entered within the three specified ranges\n");
        printf("\nTotal numbers entered is %d\n",nCount);
    
	return 0;
}

