/*
 
 Wk11Task7.c
 HCS
 
 Created by Omer Chohan on 17/12/2013.
 Copyright (c) 2013 Staffordshire University. All rights reserved.
 
 */


#include <stdio.h>
#include <stdlib.h> // To use exit(1);


int main(void)
{
	int nInputVal,              // Variable for user input
    nR1Min, nR1Max,             // Variables to store minimum and maximum value in the Range 1
    nR2Min,nR2Max,              // Variables to store minimum and maximum value in the Range 2
    nR3Min, nR3Max,             // Variables to store minimum and maximum value in the Range 3
    
	nRange1Min, nRange1Max, 
	nRange2Min, nRange2Max, 
	nRange3Min, nRange3Max, 	// Set 3 user defined ranges
    
    nCount = -1,    		// Counts how many numbers entered. Set to -1 so it does not count -9999 to end
	nCountR1 = 0,  		 	// Counter for values entered in Range 1
    nCountR2 = 0,  		 	// Counter for values entered in Range 2
    nCountR3 = 0;   		// Counter for values entered in Range 3
    
    printf("Welcome ... \nThis program will return the minimum,the maximum\n");
    printf("and the number valid values entered in the range.\nAll values inclusive in the range.\n\n");
    printf("Specify three different ranges\n");
	
    // Range 1 validity test
    printf("Minimum Value for 1st range:");
	scanf("%d", &nRange1Min);
	printf("Maximum Value for 1st range:");
    scanf("%d", &nRange1Max);
    if(nRange1Max > nRange1Min)
        printf("Range 1 fixed at: [%d] to [%d] inclusive\n", nRange1Min, nRange1Max);
	else if(nRange1Max <= nRange1Min)
	{
    	printf("Invalid range entered! Maximum value is less than or equal to the minimum value.\n");
    	exit(1);
	}
	
    // Range 2 validity test
	printf("Minimum Value for 2nd range:");
	scanf("%d", &nRange2Min);
	printf("Maximum Value for 2nd range:");
	scanf("%d", &nRange2Max);
	if((nRange2Max > nRange2Min) && (nRange2Min > nRange1Max))
        printf("Range 2 fixed at: [%d] to [%d] inclusive\n", nRange2Min, nRange2Max);
    else if(nRange2Max <= nRange2Min)
    {
    	printf("Invalid range entered! Maximum value is less than or equal to the minimum value.\n");
    	exit(1);
	}
    else if(nRange2Min <= nRange1Max)
    {
        printf("Invalid range entered! Range 2 overlaps with Range 1.\n");
        exit(1);
    }
    
    // Range 3 validity test
    printf("Minimum Value for 3rd range:");
	scanf("%d", &nRange3Min);
	printf("Maximum Value for 3rd range:");
	scanf("%d", &nRange3Max);
    if((nRange3Max > nRange3Min) && (nRange3Min > nRange2Max))
        printf("Range 3 fixed at: [%d] to [%d]\n", nRange3Min, nRange3Max);
    else if(nRange3Max <= nRange3Min)
    {
    	printf("Invalid range entered! Maximum value is less than or equal to the minimum value.\n");
    	exit(1);
	}
    else if(nRange3Min <= nRange2Max)
    {
    	printf("Invalid range entered! Range 3 overlaps with Range 2\n");
    	exit(1);
	}
    
    nR1Min = 999;
    nR1Max =  -999;
    nR2Min = 999;
	nR2Max = -999;
	nR3Min = 999;
    nR3Max = -999;
    nInputVal = 0;
    
    while(nInputVal != -9999)
	{
		printf("Input an integer within the three specified ranges, -9999 to end : ");
		scanf("%d", &nInputVal);
        
        // Stores minimum and maximum values entered by the user in the range 1
        if(nInputVal >= nRange1Min && nInputVal <= nRange1Max)
        {
			if(nInputVal <= nR1Min) nR1Min = nInputVal;
			if(nInputVal >= nR1Max) nR1Max = nInputVal;
			nCountR1++;
		}
        
        // Stores minimum and maximum values entered by the user in the range 2
        if(nInputVal >= nRange2Min && nInputVal <= nRange2Max)
        {
			if(nInputVal <= nR2Min) nR2Min = nInputVal;
			if(nInputVal >= nR2Max) nR2Max = nInputVal;
			nCountR2++;
		}
        
        // Stores minimum and maximum values entered by the user in the range 3
        if(nInputVal >= nRange3Min && nInputVal <= nRange3Max)
        {
			if(nInputVal <= nR3Min) nR3Min = nInputVal;
			if(nInputVal >= nR3Max) nR3Max = nInputVal;
			nCountR3++;
        }
        
        nCount++;
        
    }/* End of while loop */
    
    if(nCountR1 > 0) // Counts the number of values entered in the range 1
    {
        printf("Number of values in range [%d] to [%d] is: %d\n",nRange1Min,nRange1Max, nCountR1);
        printf("The maximum value was %d\n", nR1Max);
        printf("The minimum value was %d\n", nR1Min);
    }
	if(nCountR2 > 0) // Counts the number of values entered in the range 2
	{
		printf("Number of values in range [%d] to [%d] is: %d\n",nRange2Min, nRange2Max, nCountR2);
		printf("The maximum value was %d\n", nR2Max);
		printf("The minimum value was %d\n", nR2Min);
    }
	if(nCountR3 > 0) // Counts the number of values entered in the range 3
	{
		printf("Number of values in range [%d] to [%d] is: %d\n",nRange3Min, nRange3Max, nCountR3);
		printf("The maximum value was %d\n", nR3Max);
		printf("The minimum value was %d\n", nR3Min);
	}
    
    else
        printf("No values entered within the three specified ranges\n");
    	printf("Total numbers entered is %d\n",nCount);
    
	return 0;
}




