///*
// *  File.Wk12Task1.c
// *  HCS
// *
// *  Created by Omer Chohan on 30/01/2014.
// *  Copyright (c) 2014 Staffordshire University. All rights reserved.
// */
//
//
//#include <stdio.h>
//#include <stdlib.h>
//
///* Array search function header  */
//void fnSearchArray(int arnSalaries[][2]);
//
//
//int main(int argc, char *argv[])
//	{
//	 int arnSalaries[10][2] = {1, 10000, 2, 11000, 3, 12000, 4, 13000, 5, 14000, 
//	  						   6, 15000, 7, 16000, 8, 17000, 9, 18000, 10, 19000};
//	 int nRow;
//	
//	 		printf("\n\n");
//	 		printf("\tWeek 12 Tutorial\n\tFormative Task 1\n\tSearching a 2D array\n\n");
//	 
//	 /* First, print the array so that the contents can be seen */
//	 for(nRow = 0; nRow < 10; nRow++)
//	 	{
//	 		
//		 	printf("\t%6d %4d\n",arnSalaries[nRow][1], arnSalaries[nRow][0]);
//		 	
//	 	}
//	 	
//	
//			printf("\n\n");
//	
//							/* Function called in main */
//							fnSearchArray(arnSalaries); 
//	
//			printf("\n\n\n");
//	
//		system("PAUSE");
//		
//	return 0;
//	
//	}
//	
///*************************************************
// *	 1. Function Definition search for salary
// *************************************************/
//
//
//void fnSearchArray(int arnSalaries[][2])
//{
//	 	int nRow, nEmNo; 
//	 	char cFound = 'N';
//	 	
//		printf("\tPlease enter the employee number : ");
//	 	scanf("%d", &nEmNo);
//	 	
//        /* Now the search */
//        for(nRow = 0; nRow < 10; nRow++)
//            {
//	 	
//                if(nEmNo == arnSalaries[nRow][0])
//                    {
//                        printf("\n\tEmployee found - has salary of %d\n", arnSalaries[nRow][1]);
//		 		
//                        cFound = 'Y';
//		
//                        nRow = 10; /* This is to break out of the loop */
//                    }
//            }
//	
//            if(cFound == 'N')
//                {
//		
//                    printf("\tSorry, employee not found - please try again\n");
//                    
//                }
//	
//}
//	
