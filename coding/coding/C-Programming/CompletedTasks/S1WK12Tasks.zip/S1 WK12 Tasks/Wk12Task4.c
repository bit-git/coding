/*
 *  File.Wk12Task4.c
 *  HCS
 *
 *  Created by Omer Chohan on 30/01/2014.
 *  Copyright (c) 2014 Staffordshire University. All rights reserved.
 */


#include <stdio.h>
#include <stdlib.h>


/* 1. Array search function prototype */
void fnSearchArray(int arnSalaries[][2]);

/* 2. Array print function prototype */
void fnPrintArray(int arnSalaries[][2]);


int main(int argc, char *argv[])
	{
	int arnSalaries[10][2] = {21, 10000, 22, 15600, 23, 10000,
						      24, 56000, 25, 13250, 26, 24750, 
							  27, 18750, 28, 56250, 29, 22450, 
							  30, 27500};
	
			/* Print Program Intro Header */
	 		printf("\n\n");
	 		printf("\tWeek 12 Tutorial\n\tSummative Task 4\n");
			printf("\tSearching a 2D array\n");
			printf("\tof Employee IDs and Salaries.\n\n");
			
				/* First, print the array so that the contents can be seen */
				fnPrintArray(arnSalaries);
	
				/* Search function called in main */
				fnSearchArray(arnSalaries);
	
            printf("\n\n\n");
	
		
        system("PAUSE");
		
	return 0;
	
}
	
/*************************************************
 *	 1. Function Definition search for same salary
 *************************************************/
	
void fnSearchArray(int arnSalaries[][2])
{
	 int nRow, nSalary, arnSameSalary[10];
	 int nCount; 
	 char cFound = 'N';
	 
	 	printf("\tPlease enter the employee salary : ");
	 	scanf("%d", &nSalary);
	 
	 /* Now the search */
	 for(nRow = 0; nRow < 10; nRow++)
	 {
	 	if(nSalary == arnSalaries[nRow][1])
			{
				for(nCount = 0; nCount < 10; nCount++ )
					arnSameSalary[nCount] = arnSalaries[nRow][0];
							
					printf("\n\tEmployee found at index %d - has Employee ID of %d\n", 
														 nRow+1, arnSameSalary[nRow]);
				
					cFound = 'Y';
		
				/* Break loop here if checking for one employee ID for the given salary */	
				/*nRow = 10; */		
			}
	}
	
	if(cFound == 'N')
		{
			
			printf("\n\n");
			printf("\tSorry, employee not found - Have a nice day!\n");
		}
}


/***************************************
 *   2. Function Definition to Print Array
 ****************************************/
	
void fnPrintArray(int arnSalaries[][2])
{
	int nRow;
		
        printf("\t%s\t%s\n \t%s\t%s\n","Emp ID","Salaries",
	 							   "------","--------");
	 							   
        for(nRow = 0; nRow < 10; nRow++)
            {
		
                printf("\t%4d	%6d\n",arnSalaries[nRow][0], arnSalaries[nRow][1]);
	 
            }
	
        printf("\n\n");
		
}
