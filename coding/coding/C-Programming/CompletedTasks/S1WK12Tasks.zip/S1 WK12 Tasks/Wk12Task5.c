/*
 *  File.Wk12Task5.c
 *  HCS
 *
 *  Created by Omer Chohan on 30/01/2014.
 *  Copyright (c) 2014 Staffordshire University. All rights reserved.
 */


#include <stdio.h>
#include <stdlib.h>

/* 1. Array search function prototype */
/* [Row] [Col]; Row can be left empty, col is must */
void fnSearchArray(int arnSalaries[][2]);

/* 2. Array print function prototype */
void fnPrintArray(int arnSalaries[][2]);


int main(int argc, char *argv[])

    {
	 	int arnSalaries[10][2] = {21, 10000, 22, 15600, 23, 10000,
		 						  24, 56000, 25, 13250, 26, 24750, 
								  27, 18750, 28, 56250, 29, 22450, 
								  30, 27500};
        
	
	 		/* Print Program Intro Header */
	 		printf("\n\n");
	 		printf("\tWeek 12 Tutorial\n\tSummative Task 5\n");
			printf("\tSearching a 2D array\n");
			printf("\tof Employee IDs and Salaries.\n\n");
        
	 
	 			/* First, print the array so that the contents can be seen */
				fnPrintArray(arnSalaries);
	
				
                /* Search function called in main */
                fnSearchArray(arnSalaries);
	
            printf("\n\n\n");
	
		
        system("PAUSE");
			
	return 0;
}


	
/************************************************************
 *	 1. Function Definition search between max and min salary
 *************************************************************/


void fnSearchArray(int arnSalaries[][2])
{
	 int nRow, nSalaryMax, nSalaryMin;
	 int arnSameSalary[10]; 	/* Array to store max 10 same salaries for given ID */
	 int nCount; 				/* To count the same salaries */
	 char cFound = 'N';
	 
	 		printf("\tPlease enter the employee max salary: ");
	 		scanf("%d", &nSalaryMax);
	 		printf("\tPlease enter the employee min salary: ");
	 		scanf("%d", &nSalaryMin);
	 
	 	 /* Now the search */
	 for(nRow = 0; nRow < 10; nRow++)
	 	{
	 		if(nSalaryMax >= arnSalaries[nRow][1] && nSalaryMin <= arnSalaries[nRow][1])
				{
					for(nCount = 0; nCount < 10; nCount++ )
					
						arnSameSalary[nCount] = arnSalaries[nRow][0];
		
						printf("\n\tEmployee found at index %4d - Emp ID = %4d and Salary = %6d", 
											  nRow+1, arnSameSalary[nRow], arnSalaries[nRow][1]);
				
						cFound = 'Y';
		
				}
		}
	
			if(cFound == 'N')
				{
					printf("\n\n");
					printf("\tSorry, employee not found - Have a nice day!\n");
				}
}


/***************************************
 *   2. Function Definition to Print Array
 ****************************************/

	
void fnPrintArray(int arnSalaries[][2])
{
	 int nRow;
	 
	 	printf("\t%s\t%s\n \t%s\t%s\n","Emp IDs","Salaries",
	 								   "-------","--------");
    
        for(nRow = 0; nRow < 10; nRow++)
            {
	 		
                printf("\t%4d	%6d\n", arnSalaries[nRow][0], arnSalaries[nRow][1]);
		 	
            }
	
	printf("\n\n");	
		
}


