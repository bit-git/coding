/*
 *  File.Wk12Task6.c
 *  HCS
 *
 *  Copied by Omer Chohan on 30/01/2014.
 *  Copyright (c) 2014 Staffordshire University. All rights reserved.
 */



#include <stdio.h>

/* Function prototypes */
void fnOption1(void);
void fnOption2(void);
void fnOption3(void);

int main(void)
{
	int nChoice = 1;	/* Need an initial value */

	while(nChoice != 4)
	{
		printf("\n\n");
		printf("\tWeek 12\n\tFormative Task 6\n\n");
		printf("\n\n");
		printf("	Main Menu ...\n\n");
		printf("	1	Option 1\n");
		printf("	2	Option 2\n");
		printf("	3	Option 3\n");
		printf("	4	Exit\n\n");
		printf("	Please enter your choice : ");
		scanf("%d", &nChoice);
		printf("\n");

		switch(nChoice)
		{
			case 1:	fnOption1();
						break;

			case 2:	fnOption2();
						break;

			case 3:	fnOption3();
						break;

			case 4:	break;

			default:	printf("Invalid input, please try again\n\n");
		}
	}
	return 0;
}


void fnOption1(void)
{
	printf("\nYou selected Option1\n");
}

void fnOption2(void)
{
	printf("\nYou selected Option2\n");
}

void fnOption3(void)
{
	printf("\nYou selected Option3\n");
}

