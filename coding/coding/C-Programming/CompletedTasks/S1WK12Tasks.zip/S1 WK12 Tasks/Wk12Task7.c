/*
*  File.Wk12Task7.c
*  HCS
*
*  Created by Omer Chohan on 30/01/2014.
*  Copyright (c) 2014 Staffordshire University. All rights reserved.
*/


#include <stdio.h>
#include <stdlib.h>

/* Menu and options functions prototypes */
/* [Row] [Col]; Row can be left empty, col is must */

void fnMenu(int arnSalaries[][2]);                  /*  1. */
void fnOption1(int arnSalaries[][2]);               /*  2. */
void fnOption2(int arnSalaries[][2]);               /*  3. */
void fnOption3(int arnSalaries[][2]);               /*  4. */
void fnOption4(void);                               /*  5. */

/* Array search function prototypes */

void fnSearchArrayMaxMin(int arnSalaries[][2]);     /*  6. Searcg between Max Min salary */
void fnSearchArraySalary(int arnSalaries[][2]);     /*  7. Search Salary */
void fnSearchArrayEmpID(int arnSalaries[][2]);      /*  8. Search Emp ID */

/* Array print function prototype */
void fnPrintArray(int arnSalaries[][2]);            /*  9. Print Array */



int main(void)
{
	int arnSalaries[10][2] =  {21, 10000, 22, 15600, 23, 10000, 24, 56000, 25, 13250, 
	  						   26, 24750, 27, 18750, 28, 56250, 29, 22450, 30, 27500};
	  						   
			fnMenu(arnSalaries);
	
	return 0;
	
}


/*
**********************Function Definitions*********************
***************************************************************
*/


/************************
/	1. Funtion Print Menu
*************************/

void fnMenu(int arnSalaries[][2])
{
	int nChoice = 1;	/* Need an initial value */

	while(nChoice != 4)
	{
			/* Print Program Intro Header */
	 		printf("\n\n");
	 		printf("\tWeek 12 Tutorial\n\tSummative Task 7\n");
			printf("\tSearching a 2D array\n");
			printf("\tof Employee IDs and Salaries.\n\n");
			printf("\n\n");
			printf("	Main Menu\n\n");
			printf("	Please select from the following search options :\n");
			printf("	1	Between maximum and minimum salary\n");
			printf("	2	By salary\n");
			printf("	3	By Employee ID\n");
			printf("	4	Exit\n\n");
			printf("	Please enter your choice 1 - 4 : ");
			scanf("%d", &nChoice);
			printf("\n");

		switch(nChoice)
		{
			case 1:	fnOption1(arnSalaries);
						break;

			case 2:	fnOption2(arnSalaries);
						break;

			case 3:	fnOption3(arnSalaries);
						break;

			case 4:	fnOption4();
						break;

			default:	printf("\tInvalid input, please try again\n\n");
		}
	}
}


/*******************************
*	2. Funtion - Menu Option 1
********************************/


void fnOption1(int arnSalaries[][2])
{
	system("cls"); 	/* Clear screen */					   
	
	printf("\n\tYou selected option 1: To search between maximum and minimum salary.\n");
	
		
        fnPrintArray(arnSalaries);
		
        fnSearchArrayMaxMin(arnSalaries);
	
	printf("\n\n");
	
	system("PAUSE");
	system("cls");	/* Clear screen */
}


/******************************
*   3. Function - Menu Option 2
*******************************/

void fnOption2(int arnSalaries[][2])
{
	system("cls"); 	/* Clear screen */
	printf("\n\tYou selected option 2: To search by salary.\n\n");
		
		fnPrintArray(arnSalaries);	
		fnSearchArraySalary(arnSalaries);
		
	printf("\n\n");
	
	system("PAUSE");
	system("cls");		/* Clear screen */	
}


/********************************
*	4. Function - Menu Option 3
*********************************/

void fnOption3(int arnSalaries[][2])
{
	system("cls"); 	/* Clear screen */
	printf("\n\tYou selected option 3: To search by Employee ID.\n\n");
	
		fnPrintArray(arnSalaries);	
		fnSearchArrayEmpID(arnSalaries);
		
	printf("\n\n");
	
	system("PAUSE");
	system("cls");	/* Clear screen */	
}


/*******************************
*	5. Funtion - Menu Option 4
********************************/

void fnOption4(void)
{
	system("cls");
	printf("\n\n");
	printf("\tYou selected option 4: To exit.\n\n\tHave a nice day...!\n\n");
	
}


/************************************************************
*	 6. Function Definition search between max and min salary
*************************************************************/

void fnSearchArrayMaxMin(int arnSalaries[][2])
{
	 int nRow, nSalaryMax, nSalaryMin;
	 int arnSameSalary[10]; 	/* Array to store max 10 same salaries for given ID */
	 int nCount; 				/* To count the same salaries */
	 char cFound = 'N';
	 
	 printf("\tPlease enter the employee max salary: ");
	 scanf("%6d", &nSalaryMax);
	 printf("\tPlease enter the employee min salary: ");
	 scanf("%6d", &nSalaryMin);
	 
	 /* Now the search */
	 for(nRow = 0; nRow < 10; nRow++)
	 	{
	 		if(nSalaryMax >= arnSalaries[nRow][1] && nSalaryMin <= arnSalaries[nRow][1])
				{
					for(nCount = 0; nCount < 10; nCount++ )
						arnSameSalary[nCount] = arnSalaries[nRow][0];
		
							printf("\n\tEmployee found at index %4d - Emp ID = %4d and Salary = %6d", 
												  nRow+1, arnSameSalary[nRow], arnSalaries[nRow][1]);
				
							cFound = 'Y';
			
				}
		}
	
			if(cFound == 'N')
				{
					printf("\n\n");
					printf("\tSorry, employee not found - Please try again!\n");
				}
}
	
	
/*******************************************
*	7. Function Definition search by Salary
********************************************/

void fnSearchArraySalary(int arnSalaries[][2])
{
	 int nRow, nSalary, arnSameSalary[10];          /* arnSameSalary will store same salary found */
	 int nCount;                                    /* nCount to write to next index */
	 char cFound = 'N';
	 
	 printf("\tPlease enter the employee salary : ");
	 scanf("%d", &nSalary);
	 
	 /* Now the search */
	 for(nRow = 0; nRow < 10; nRow++)
	 	{
	 		if(nSalary == arnSalaries[nRow][1])
				{
					/* for loop to return more than one result found */
                    for(nCount = 0; nCount < 10; nCount++ )
						
                        arnSameSalary[nCount] = arnSalaries[nRow][0];
							
							printf("\n\tEmployee found at index %2d - has Employee ID of %2d\n",
																   nRow+1, arnSameSalary[nRow]);
				
							cFound = 'Y';
				
				}
		}
	
			if(cFound == 'N')
				{
					printf("\n\n");
					printf("\tSorry, employee not found - Please try again!\n");
				}
}
	

/***********************************************
*	8. Function Definition seacrh by Employee ID
************************************************/


void fnSearchArrayEmpID(int arnSalaries[][2])
{
	 int nRow, nEmpID; 
	 char cFound = 'N';
	 
	 printf("\tPlease enter the employee ID : ");
	 scanf("%d", &nEmpID);
	 
	 /* Now the search */
	 for(nRow = 0; nRow < 10; nRow++)
	 	{
	 		if(nEmpID == arnSalaries[nRow][0])
				{
					printf("\n\tEmployee found - has salary of %6d\n",
												arnSalaries[nRow][1]);
		 		
					cFound = 'Y';
					nRow = 10; /* This is to break out of the loop */
				}
		}
	
			if(cFound == 'N')
				{
					
					printf("\tSorry, employee not found - please try again\n");
	
				}
	}


/***************************************
*   9. Function Definition to Print Array
****************************************/
	
void fnPrintArray(int arnSalaries[][2])
{
	int nRow;
	
		/* First, print the array so that the contents can be seen */
	 	printf("\t%s\t%s\n \t%s\t%s\n","Emp ID","Salaries",
	 								   "------","--------");
	 	for(nRow = 0; nRow < 10; nRow++)
	 		{
	 			
		 		printf("\t%4d	%6d\n",arnSalaries[nRow][0], arnSalaries[nRow][1]);
	 		
			}
			 
	printf("\n\n");
	
}










