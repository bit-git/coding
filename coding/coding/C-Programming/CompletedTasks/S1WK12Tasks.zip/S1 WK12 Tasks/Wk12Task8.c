//#include <stdio.h>
//#include <stdlib.h>
//#if defined POSIX
//  #define CLEARSCR system ( "clear" )
//#elif defined MSDOS || defined WIN32
//  #define CLEARSCR system ( "cls" )
//#endif
//
///* Function prototypes */
//void fnOption1(void);
//void fnOption2(void);
//void fnOption3(void);
//void fnOption4(void);
///* Array search function prototype */
//void fnSearchArrayMaxMin(int arnSalaries[][2]); 	/* [Row] [Col]; Row can be left empty, col is must */
//void fnSearchArraySalary(int arnSalaries[][2]);
//void fnSearchArrayEmpID(int arnSalaries[][2]);
//
//int main(void)
//{
//	int nChoice = 1;	/* Need an initial value */
//
//	while(nChoice != 4)
//	{
//		printf("\n\n");
//		printf("\tWeek 12\n\tSummative Task 7\n\tSearching a 2D array\n\tof Employee IDs and Salaries.\n");
//		printf("\n\n");
//		printf("	Main Menu\n\n");
//		printf("	Please select from the following search options :\n");
//		printf("	1	Between maximum and minimum salary\n");
//		printf("	2	By salary\n");
//		printf("	3	By Employee ID\n");
//		printf("	4	Exit\n\n");
//		printf("	Please enter your choice 1 - 4 : ");
//		scanf("%d", &nChoice);
//		printf("\n");
//
//		switch(nChoice)
//		{
//			case 1:	fnOption1();
//						break;
//
//			case 2:	fnOption2();
//						break;
//
//			case 3:	fnOption3();
//						break;
//
//			case 4:	fnOption4();
//						break;
//
//			default:	printf("\tInvalid input, please try again\n\n");
//		}
//	}
//		return 0;
//}
//
//
//void fnOption1(void)
//{
//	int arnSalaries[10][2] =  {21, 10000, 22, 15600, 23, 10000, 24, 56000, 25, 13250, 
//	  						   26, 24750, 27, 18750, 28, 56250, 29, 22450, 30, 27500};
//	system("cls"); 	/* Clear screen */					   
//	printf("\n\tYou selected to search between maximum and minimum salary.\n");
//	fnSearchArrayMaxMin(arnSalaries);
//	printf("\n\n");
//	system("PAUSE");
//	system("cls");	/* Clear screen */
//}
//
//void fnOption2(void)
//{
//	int arnSalaries[10][2] =  {21, 10000, 22, 15600, 23, 10000, 24, 56000, 25, 13250, 
//	  						   26, 24750, 27, 18750, 28, 56250, 29, 22450, 30, 27500};
//	int nRow;
//	
//	system("cls"); 	/* Clear screen */
//	printf("\n\tYou selected to search by salary.\n\n");
//	/* First, print the array so that the contents can be seen */
//	 printf("\t%s\t%s\n \t%s\t%s\n","Emp ID","Salaries",
//	 								"------","--------");
//	 for(nRow = 0; nRow < 10; nRow++)
//	 {
//		 printf("\t%4d	%6d\n",arnSalaries[nRow][0], arnSalaries[nRow][1]);
//	 }
//	printf("\n\n");
//	
//	fnSearchArraySalary(arnSalaries);
//	printf("\n\n");
//	system("PAUSE");
//	system("cls");		/* Clear screen */	
//}
//
//void fnOption3(void)
//{
//	int arnSalaries[10][2] =  {21, 10000, 22, 15600, 23, 10000, 24, 56000, 25, 13250, 
//	  						   26, 24750, 27, 18750, 28, 56250, 29, 22450, 30, 27500};
//	int nRow;
//	system("cls"); 	/* Clear screen */
//	printf("\n\tYou selected to search by Employee ID.\n\n");
//	/* First, print the array so that the contents can be seen */
//	 printf("\t%s\t%s\n \t%s\t%s\n","Emp ID","Salaries",
//	 								"------","--------");
//	 for(nRow = 0; nRow < 10; nRow++)
//	 {
//		 printf("\t%4d	%6d\n",arnSalaries[nRow][0], arnSalaries[nRow][1]);
//	 }
//	printf("\n\n");
//	
//	fnSearchArrayEmpID(arnSalaries);
//	printf("\n\n");
//	system("PAUSE");
//	system("cls");	/* Clear screen */	
//}
//
//void fnOption4(void)
//{
//	system("cls");
//	printf("\n\n");
//	printf("\tYou selected to exit.\n\tHave a nice day...!\n\n");
//	
//}
//
///* Function Definition search between max and min salary */
//void fnSearchArrayMaxMin(int arnSalaries[][2])
//	{
//	 int nRow, nSalaryMax, nSalaryMin;
//	 int arnSameSalary[10]; 	/* Array to store max 10 same salaries for given ID */
//	 int nCount; 				/* To count the same salaries */
//	 char cFound = 'N';
//	 printf("\tPlease enter the employee max salary: ");
//	 scanf("%6d", &nSalaryMax);
//	 printf("\tPlease enter the employee min salary: ");
//	 scanf("%6d", &nSalaryMin);
//	 
//	 /* Now the search */
//	 for(nRow = 0; nRow < 10; nRow++)
//	 {
//	 if(nSalaryMax >= arnSalaries[nRow][1] && nSalaryMin <= arnSalaries[nRow][1])
//		{
//		for(nCount = 0; nCount < 10; nCount++ )
//		arnSameSalary[nCount] = arnSalaries[nRow][0];
//		
//		printf("\n\tEmployee found at index %4d - Emp ID = %4d and Salary = %6d", 
//											nRow+1, arnSameSalary[nRow], arnSalaries[nRow][1]);
//				
//		cFound = 'Y';
//				
//		/* Break loop here if checking for one employee ID for given salary	 
//		nRow = 10; */		
//		}
//	}
//	
//	if(cFound == 'N')
//	{
//	printf("\n\n");
//	printf("\tSorry, employee not found - Please try again!\n");
//	}
//	}
//	
///* Function Definition search by Salary */
//void fnSearchArraySalary(int arnSalaries[][2])
//	{
//	 int nRow, nSalary, arnSameSalary[10];
//	 int nCount; 
//	 char cFound = 'N';
//	 printf("\tPlease enter the employee salary : ");
//	 scanf("%d", &nSalary);
//	 /* Now the search */
//	 for(nRow = 0; nRow < 10; nRow++)
//	 {
//	 if(nSalary == arnSalaries[nRow][1])
//		{
//		for(nCount = 0; nCount < 10; nCount++ )
//		arnSameSalary[nCount] = arnSalaries[nRow][0];
//							
//		printf("\n\tEmployee found at index %2d - has Employee ID of %2d\n", nRow+1, arnSameSalary[nRow]);
//				
//		cFound = 'Y';
//		
//		/* Break loop here if checking for one employee ID for the given salary	
//		nRow = 10; */		
//		}
//	}
//	
//	if(cFound == 'N')
//	{
//	printf("\n\n");
//	printf("\tSorry, employee not found - Please try again!\n");
//	}
//	}
//	
///* Function Definition seacrh by Employee ID*/
//void fnSearchArrayEmpID(int arnSalaries[][2])
//	{
//	 int nRow, nEmpID; 
//	 char cFound = 'N';
//	 printf("\tPlease enter the employee ID : ");
//	 scanf("%d", &nEmpID);
//	 /* Now the search */
//	 for(nRow = 0; nRow < 10; nRow++)
//	 {
//	 if(nEmpID == arnSalaries[nRow][0])
//		{
//		printf("\n\tEmployee found - has salary of %6d\n", arnSalaries[nRow][1]);
//		 		
//		cFound = 'Y';
//		nRow = 10; /* This is to break out of the loop */
//		}
//	}
//	
//	if(cFound == 'N')
//	{
//	printf("\tSorry, employee not found - please try again\n");
//	}
//	}
